document.addEventListener('DOMContentLoaded', () => {
    const modal = document.getElementById('config-modal');
    const sendingModal = document.getElementById('sending-modal');
    const settingsBtn = document.getElementById('settings-btn');
    const closeBtn = document.getElementsByClassName('close')[0];
    const saveConfigBtn = document.getElementById('save-config-btn');
    const apiUrlInput = document.getElementById('api-url');
    const syncBtn = document.getElementById('sync-btn');
    const responseMessage = document.getElementById('response-message');

    function getCookie(name) {
        const cookies = document.cookie.split("; ")
      
        return cookies
          .map((cookie) => cookie.split("="))
          .find(([key, _]) => key === name)
          ?.[1] ?? null
      }
  
    // Check if API URL is stored
    const storedApiUrl = localStorage.getItem('createCustomerApiUrl');
    if (!storedApiUrl) {
      modal.style.display = 'block'; // Show modal on first load
    } else {
      apiUrlInput.value = storedApiUrl;
    }
  
    // Open modal for settings
    settingsBtn.onclick = function() {
      modal.style.display = 'block';
    };
  
    // Close the modal
    closeBtn.onclick = function() {
      modal.style.display = 'none';
    };
  
    // Save configuration
    saveConfigBtn.onclick = function() {
      const apiUrl = apiUrlInput.value.trim();
      if (apiUrl) {
        localStorage.setItem('createCustomerApiUrl', apiUrl);
        modal.style.display = 'none';
        alert('Configuration saved!');
      } else {
        alert('Please enter a valid API URL.');
      }
    };
  
    // Sync with core
    syncBtn.onclick = async function() {
      const apiUrl = localStorage.getItem('createCustomerApiUrl');
      if (!apiUrl) {
        alert('Please configure the API URL first.');
        return;
      }
  
      const firstname = document.getElementById('firstname').value.trim();
      const lastname = document.getElementById('lastname').value.trim();
      const email = document.getElementById('email').value.trim();
      const dob = document.getElementById('dob').value;
  
      if (!firstname || !lastname || !email || !dob) {
        responseMessage.textContent = 'Please fill in all fields.';
        return;
      }
  
      const payload = {
        firstname,
        lastname,
        email,
        dob
      };
  
      // Show sending modal
      sendingModal.style.display = 'block';
  
      try {
  
        const response = await fetch(apiUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCookie("csrftoken"),
          },
          body: JSON.stringify({ ...payload })
        });
  
        sendingModal.style.display = 'none'; // Hide sending modal
  
        if (response.ok) {
          responseMessage.textContent = 'Sync successful!';
        } else {
          responseMessage.textContent = 'Sync error: ' + response.statusText;
        }
      } catch (error) {
        sendingModal.style.display = 'none'; // Hide sending modal
        responseMessage.textContent = 'Sync error: ' + error.message;
      }
    };
  });
  